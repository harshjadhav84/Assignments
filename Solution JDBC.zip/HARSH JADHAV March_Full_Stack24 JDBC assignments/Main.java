import java.sql.*;
import java.util.Scanner;

public class Main {

    static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/employee_management";
    static final String USER = "root";
    static final String PASS = "Harsh@123";

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected to the database.");

            while (true) {
                System.out.println("\nEmployee Management System Menu:");
                System.out.println("1. Add a new employee");
                System.out.println("2. Update employee details");
                System.out.println("3. Delete an employee");
                System.out.println("4. Display all employees");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1:
                        addEmployee(conn);
                        break;
                    case 2:
                        updateEmployee(conn);
                        break;
                    case 3:
                        deleteEmployee(conn);
                        break;
                    case 4:
                        displayAllEmployees(conn);
                        break;
                    case 5:
                        System.out.println("Exiting the program. Goodbye!");
                        conn.close();
                        return;
                    default:
                        System.out.println("Invalid choice. Please enter a number between 1 and 5.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Connection failed. Check output console.");
            e.printStackTrace();
        }
    }

    private static void addEmployee(Connection conn) throws SQLException {
        System.out.println("\nAdding a new employee:");
        System.out.print("Enter employee ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter employee name: ");
        String name = scanner.nextLine();
        System.out.print("Enter employee department: ");
        String department = scanner.nextLine();
        System.out.print("Enter employee salary: ");
        double salary = scanner.nextDouble();

        String sql = "INSERT INTO employees (id, name, department, salary) VALUES (?, ?, ?, ?)";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setInt(1, id);
        statement.setString(2, name);
        statement.setString(3, department);
        statement.setDouble(4, salary);

        int rowsInserted = statement.executeUpdate();
        if (rowsInserted > 0) {
            System.out.println("Employee added successfully!");
        } else {
            System.out.println("Failed to add employee.");
        }
    }

    private static void updateEmployee(Connection conn) throws SQLException {
        System.out.println("\nUpdating employee details:");
        System.out.print("Enter employee ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter new name (leave empty to skip): ");
        String name = scanner.nextLine();
        System.out.print("Enter new department (leave empty to skip): ");
        String department = scanner.nextLine();
        System.out.print("Enter new salary (leave empty to skip): ");
        String salaryStr = scanner.nextLine();

        StringBuilder sqlBuilder = new StringBuilder("UPDATE employees SET ");
        boolean hasUpdate = false;
        if (!name.isEmpty()) {
            sqlBuilder.append("name = '").append(name).append("'");
            hasUpdate = true;
        }
        if (!department.isEmpty()) {
            if (hasUpdate) {
                sqlBuilder.append(", ");
            }
            sqlBuilder.append("department = '").append(department).append("'");
            hasUpdate = true;
        }
        if (!salaryStr.isEmpty()) {
            double salary = Double.parseDouble(salaryStr);
            if (hasUpdate) {
                sqlBuilder.append(", ");
            }
            sqlBuilder.append("salary = ").append(salary);
            hasUpdate = true;
        }
        sqlBuilder.append(" WHERE id = ").append(id);

        String sql = sqlBuilder.toString();
        Statement statement = conn.createStatement();

        int rowsUpdated = statement.executeUpdate(sql);
        if (rowsUpdated > 0) {
            System.out.println("Employee details updated successfully!");
        } else {
            System.out.println("No employee found with ID " + id);
        }
    }

    private static void deleteEmployee(Connection conn) throws SQLException {
        System.out.println("\nDeleting an employee:");
        System.out.print("Enter employee ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        String sql = "DELETE FROM employees WHERE id = ?";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setInt(1, id);

        int rowsDeleted = statement.executeUpdate();
        if (rowsDeleted > 0) {
            System.out.println("Employee deleted successfully!");
        } else {
            System.out.println("No employee found with ID " + id);
        }
    }

    private static void displayAllEmployees(Connection conn) throws SQLException {
        System.out.println("\nList of all employees:");
        Statement statement = conn.createStatement();
        String sql = "SELECT id, name, department, salary FROM employees";
        ResultSet result = statement.executeQuery(sql);

        while (result.next()) {
            int id = result.getInt("id");
            String name = result.getString("name");
            String department = result.getString("department");
            double salary = result.getDouble("salary");

            System.out.println("ID: " + id + ", Name: " + name + ", Department: " + department + ", Salary: " + salary);
        }
    }
}
